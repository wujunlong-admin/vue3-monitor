declare const ElMessage: typeof import('element-plus')['ElMessage']
declare const ElMessageBox: typeof import('element-plus')['ElMessageBox']
