declare interface IUser {
  token: string | undefined
}

declare interface ILogin {
  account: string
  pwd: string
}
