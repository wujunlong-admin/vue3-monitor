declare type IDictionary<T> = { [key: string]: T }
