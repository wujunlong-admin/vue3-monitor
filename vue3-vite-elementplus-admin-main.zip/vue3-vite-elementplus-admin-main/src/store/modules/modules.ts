const state = {}
const mutations = {}
const actions = {}
const getters = {}
const user = {
  state,
  mutations,
  actions,
  getters
}
export default user
