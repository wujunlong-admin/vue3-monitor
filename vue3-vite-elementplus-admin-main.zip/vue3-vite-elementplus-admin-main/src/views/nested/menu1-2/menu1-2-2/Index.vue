<template>
  <div class="menu1-2-2">menu1-2-2</div>
</template>
<style lang="scss">
.menu1-2-2 {
  width: 400px;
  height: 200px;
  background: rgb(165, 243, 243);
  padding: 15px;
}
</style>
