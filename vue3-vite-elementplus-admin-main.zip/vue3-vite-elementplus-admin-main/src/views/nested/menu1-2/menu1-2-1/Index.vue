<template>
  <div class="menu1-2-1">menu1-2-1</div>
</template>
<style lang="scss">
.menu1-2-1 {
  width: 400px;
  height: 200px;
  background: rgb(241, 230, 162);
  padding: 15px;
}
</style>
