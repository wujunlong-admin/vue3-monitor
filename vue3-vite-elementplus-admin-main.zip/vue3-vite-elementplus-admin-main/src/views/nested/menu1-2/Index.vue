<template>
  <div class="menu1-2">
    menu1-2
    <router-view></router-view>
  </div>
</template>
<style lang="scss">
.menu1-2 {
  width: 500px;
  height: 300px;
  background: rgb(248, 218, 218);
  padding: 15px;
}
</style>
