<template>
  <div class="menu1-1">menu1-1</div>
</template>
<style lang="scss">
.menu1-1 {
  width: 500px;
  height: 300px;
  background: rgb(248, 218, 218);
  padding: 15px;
}
</style>
