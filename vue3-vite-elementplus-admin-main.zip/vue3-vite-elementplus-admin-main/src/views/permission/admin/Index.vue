<template>
  <div class="admin">
    <div class="container">【管理员：admin】才可看到该界面</div>
  </div>
</template>
<style lang="scss" scoped>
.admin {
  padding: 20px;
  .container {
    background: #fff;
    border-radius: 5px;
    height: calc(100vh - 131px);
    padding: 20px;
  }
}
</style>
