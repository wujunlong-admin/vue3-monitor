<template>
  <div class="visitor">
    <div class="container">【访客：visitor】才可看到该界面</div>
  </div>
</template>
<style lang="scss" scoped>
.visitor {
  padding: 20px;
  .container {
    background: #fff;
    border-radius: 5px;
    height: calc(100vh - 131px);
    padding: 20px;
  }
}
</style>
