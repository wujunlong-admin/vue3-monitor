export const UserRankChina = [
  { name: '广东省', value: 290 },
  { name: '浙江省', value: 180 },
  { name: '上海市', value: 164 },
  { name: '江苏省', value: 155 },
  { name: '四川省', value: 142 },
  { name: '福建省', value: 55 },
  { name: '湖南省', value: 39 }
]

export const UserRankWorld = [
  { name: '中国', value: 199 },
  { name: '美国', value: 180 },
  { name: '日本', value: 39 },
  { name: '法国', value: 55 },
  { name: '英国', value: 15 }
]
